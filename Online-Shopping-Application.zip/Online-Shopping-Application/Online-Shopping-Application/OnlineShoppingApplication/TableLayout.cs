﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CartProcess;

namespace UI
{
    public class TableLayout
    {

        public static void ItemTable()
        {


            Console.Clear();

            Console.WriteLine();
            Console.WriteLine("Select items from below: ");
            Console.WriteLine();

            PrintLine();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\t\tFruits\t\t\tPrices");
            Console.ResetColor();
            PrintLine();
            Console.WriteLine("\t\tApple\t\t\t15 PHP per piece");
            Console.WriteLine("\t\tBanana\t\t\t55 PHP per piece");
            Console.WriteLine("\t\tMango\t\t\t155 PHP per piece");
            Console.WriteLine();

            PrintLine();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\t\tVegetables\t\tPrices");
            Console.ResetColor();
            PrintLine();
            Console.WriteLine("\t\tAmpalaya\t\t105 PHP per Kilo");
            Console.WriteLine("\t\tMalungay\t\t110 PHP per Kilo");
            Console.WriteLine("\t\tPotato  \t\t120 PHP per Kilo");
            Console.WriteLine();

            PrintLine();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\t\tMeat\t\t\tPrices");
            Console.ResetColor();
            PrintLine();
            Console.WriteLine("\t\tChicken\t\t\t150 PHP per Kilo");
            Console.WriteLine("\t\tBeef\t\t\t400 PHP per Kilo");
            Console.WriteLine("\t\tPork\t\t\t350 PHP per Kilo");
            Console.WriteLine();

            PrintLine();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\t\tSnacks\t\t\tPrices");
            Console.ResetColor();
            PrintLine();
            Console.WriteLine("\t\tVCut\t\t\t15 PHP per piece");
            Console.WriteLine("\t\tPiatos\t\t\t15 PHP per piece");
            Console.WriteLine("\t\tClover\t\t\t7 PHP per piece");
            Console.WriteLine();

            PrintLine();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\t\tBeverages\t\tPrices");
            Console.ResetColor();
            PrintLine();
            Console.WriteLine("\t\tChucky\t\t\t85 PHP per carton");
            Console.WriteLine("\t\tSoda\t\t\t85 PHP per Bottle");
            Console.WriteLine("\t\tJuice\t\t\t30 PHP per Sachet");
            Console.WriteLine();


        }

        public static void PrintLine()
        {
            Console.WriteLine(new string('-', Layouts.tableWidth));
        }

    }
}
