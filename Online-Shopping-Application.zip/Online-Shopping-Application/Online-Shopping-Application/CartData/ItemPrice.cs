﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CartData
{
    public enum ItemPrice
    {
        apple = 15,
        banana = 55,
        mango = 155,
        ampalaya = 105,
        malungay = 110,
        potato = 120,
        chicken = 150,
        beef = 400,
        pork = 350,
        vcut = 15,
        piatos = 15,
        clover = 7,
        chucky = 85,
        soda = 85,
        juice = 30,

    }
}